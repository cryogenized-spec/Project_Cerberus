import React, { useEffect, useRef, useState } from 'react';
import ReactMarkdown from 'react-markdown';
import { Send, Menu, Sparkles, MapPin } from 'lucide-react';
import { Message, Room, CharacterProfile } from '../types';
import Portrait from './Portrait';

interface ChatAreaProps {
  messages: Message[];
  isStreaming: boolean;
  onSendMessage: (content: string) => void;
  onSidebarToggle: () => void;
  character: CharacterProfile;
  portraitScale: number;
  activeRoom: Room;
  rooms: Room[];
  onRoomChange: (roomId: string) => void;
}

const ChatArea: React.FC<ChatAreaProps> = ({
  messages,
  isStreaming,
  onSendMessage,
  onSidebarToggle,
  character,
  portraitScale,
  activeRoom,
  rooms,
  onRoomChange
}) => {
  const [input, setInput] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Auto-scroll to bottom
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isStreaming]);

  // Auto-resize textarea
  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = `${Math.min(textareaRef.current.scrollHeight, 120)}px`;
    }
  }, [input]);

  const handleSubmit = (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!input.trim() || isStreaming) return;
    onSendMessage(input);
    setInput('');
    if (textareaRef.current) textareaRef.current.style.height = 'auto';
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSubmit();
    }
  };

  return (
    <div className="flex-1 flex flex-col h-full relative bg-cerberus-void bg-[url('https://www.transparenttextures.com/patterns/stardust.png')]">
      
      {/* Header / Room Selector */}
      <div className="absolute top-0 left-0 right-0 z-10 p-4 bg-gradient-to-b from-cerberus-void via-cerberus-void/90 to-transparent flex justify-between items-start pointer-events-none">
        <div className="pointer-events-auto flex items-center gap-2">
           <button onClick={onSidebarToggle} className="md:hidden text-cerberus-accent p-2 bg-cerberus-900/50 rounded-full backdrop-blur">
            <Menu size={20} />
          </button>
          
          <div className="group relative">
             <button className="flex items-center gap-2 text-cerberus-accent bg-cerberus-900/80 backdrop-blur border border-cerberus-700 px-3 py-1.5 rounded-full text-xs font-serif tracking-widest uppercase hover:bg-cerberus-800 transition-all">
                <MapPin size={12} />
                <span>{activeRoom.name}</span>
             </button>
             {/* Room Dropdown */}
             <div className="absolute top-full left-0 mt-2 w-56 bg-cerberus-900 border border-cerberus-700 rounded shadow-xl overflow-hidden opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 transform origin-top-left">
                {rooms.map(room => (
                    <div 
                        key={room.id}
                        onClick={() => onRoomChange(room.id)}
                        className={`p-3 cursor-pointer hover:bg-cerberus-800 transition-colors border-b border-cerberus-800 last:border-0 ${activeRoom.id === room.id ? 'bg-cerberus-800/50 text-cerberus-accent' : 'text-gray-400'}`}
                    >
                        <div className="font-serif text-sm font-bold mb-1">{room.name}</div>
                        <div className="text-[10px] leading-tight opacity-70 line-clamp-2">{room.description}</div>
                    </div>
                ))}
             </div>
          </div>
        </div>

        {/* Portrait */}
        <div className="pointer-events-auto transition-transform duration-300 origin-top-right drop-shadow-2xl">
           <Portrait url={character.portraitUrl} scale={portraitScale} />
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto px-4 md:px-16 lg:px-32 pt-24 pb-4 space-y-8">
        {messages.length === 0 && (
          <div className="h-full flex flex-col items-center justify-center text-cerberus-600 opacity-30 select-none">
             <Sparkles size={48} className="mb-4 animate-pulse" />
             <p className="font-serif text-xl">The Void awaits your voice...</p>
          </div>
        )}

        {messages.map((msg, idx) => (
          <div key={msg.id} className={`flex flex-col ${msg.role === 'model' ? 'items-start' : 'items-end'}`}>
            <div className={`max-w-3xl w-full ${msg.role === 'model' ? 'text-left' : 'text-right'}`}>
              <span className={`text-xs uppercase tracking-widest mb-1 block font-bold ${msg.role === 'model' ? 'text-cerberus-accent' : 'text-gray-500'}`}>
                {msg.role === 'model' ? character.name : 'You'}
              </span>
              <div 
                className={`
                   prose prose-invert max-w-none leading-relaxed
                   ${msg.role === 'model' 
                     ? 'font-serif text-gray-200 text-lg lg:text-xl drop-shadow-md' 
                     : 'font-sans text-gray-400 text-base bg-cerberus-900/40 p-3 rounded-lg inline-block border border-cerberus-800/50'}
                `}
              >
                <ReactMarkdown>{msg.content}</ReactMarkdown>
              </div>
            </div>
          </div>
        ))}
        <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <div className="p-4 md:p-6 bg-gradient-to-t from-cerberus-void via-cerberus-void to-transparent z-20">
        <div className="max-w-4xl mx-auto relative">
          <textarea
            ref={textareaRef}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Speak to the Void..."
            className="w-full bg-cerberus-900/90 backdrop-blur-md border border-cerberus-700 text-gray-200 rounded-lg pl-4 pr-12 py-4 focus:outline-none focus:border-cerberus-500 focus:ring-1 focus:ring-cerberus-500 resize-none shadow-2xl custom-scrollbar"
            rows={1}
            disabled={isStreaming}
          />
          <button
            onClick={() => handleSubmit()}
            disabled={!input.trim() || isStreaming}
            className={`
              absolute right-3 bottom-3 p-2 rounded-full transition-all duration-200
              ${!input.trim() || isStreaming ? 'text-gray-600' : 'text-cerberus-accent hover:bg-cerberus-800 hover:text-white'}
            `}
          >
            <Send size={20} />
          </button>
        </div>
        <div className="text-center mt-2">
            <p className="text-[10px] text-cerberus-600/50 font-mono uppercase tracking-widest">Project Cerberus v1.0 // Private Link Established</p>
        </div>
      </div>
    </div>
  );
};

export default ChatArea;
