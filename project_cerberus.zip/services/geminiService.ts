import { GoogleGenAI, HarmCategory, HarmBlockThreshold } from '@google/genai';
import { Message, Room, CharacterProfile, AppSettings } from '../types';

export const streamGeminiResponse = async (
  messages: Message[],
  room: Room,
  settings: AppSettings,
  character: CharacterProfile,
  onChunk: (text: string) => void
): Promise<string> => {
  if (!settings.apiKeyGemini) {
    throw new Error("Gemini API Key is missing.");
  }

  const ai = new GoogleGenAI({ apiKey: settings.apiKeyGemini });

  // Construct the full system instruction including room context
  const fullSystemInstruction = `
${character.systemPrompt}

**Current Location:** ${room.name}
**Location Description:** ${room.description}
**User Name:** ${settings.userName}
`;

  // Filter and format history. 
  // Gemini expects roles 'user' and 'model'.
  // We take the last N messages to fit context if needed, but Gemini usually handles large context well.
  const history = messages.map(m => ({
    role: m.role,
    parts: [{ text: m.content }]
  }));

  const lastMessage = history.pop();

  if (!lastMessage) {
      throw new Error("No message to send.");
  }

  try {
    const chat = ai.chats.create({
        model: settings.modelGemini,
        config: {
            systemInstruction: fullSystemInstruction,
            temperature: settings.temperature,
            safetySettings: [
                { category: HarmCategory.HARM_CATEGORY_HARASSMENT, threshold: HarmBlockThreshold.BLOCK_NONE },
                { category: HarmCategory.HARM_CATEGORY_HATE_SPEECH, threshold: HarmBlockThreshold.BLOCK_NONE },
                { category: HarmCategory.HARM_CATEGORY_SEXUALLY_EXPLICIT, threshold: HarmBlockThreshold.BLOCK_NONE },
                { category: HarmCategory.HARM_CATEGORY_DANGEROUS_CONTENT, threshold: HarmBlockThreshold.BLOCK_NONE },
            ],
        },
        history: history,
    });

    const result = await chat.sendMessageStream({ message: lastMessage.parts[0].text });

    let fullText = "";
    for await (const chunk of result) {
      const text = chunk.text;
      if (text) {
        fullText += text;
        onChunk(text);
      }
    }
    return fullText;

  } catch (error) {
    console.error("Gemini API Error:", error);
    throw error;
  }
};

export const testGeminiConnection = async (apiKey: string): Promise<boolean> => {
  try {
    const ai = new GoogleGenAI({ apiKey });
    const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: 'Ping',
    });
    return !!response.text;
  } catch (e) {
    console.error(e);
    return false;
  }
};
