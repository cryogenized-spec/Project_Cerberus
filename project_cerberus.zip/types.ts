export type Role = 'user' | 'model';

export interface Message {
  id: string;
  role: Role;
  content: string;
  timestamp: number;
}

export interface Thread {
  id: string;
  title: string;
  messages: Message[];
  lastUpdated: number;
}

export interface Room {
  id: string;
  name: string;
  description: string;
}

export interface CharacterProfile {
  name: string;
  systemPrompt: string;
  portraitUrl: string;
}

export interface AppSettings {
  apiKeyGemini: string;
  apiKeyGrok: string;
  activeProvider: 'gemini' | 'grok';
  modelGemini: string;
  modelGrok: string;
  portraitScale: number; // 0.5 to 2.0
  userName: string;
  temperature: number;
}

export interface ChatState {
  threads: Thread[];
  activeThreadId: string | null;
  rooms: Room[];
  activeRoomId: string;
  settings: AppSettings;
  character: CharacterProfile;
}

export const DEFAULT_GEMINI_MODEL = 'gemini-3-pro-preview';
export const DEFAULT_GROK_MODEL = 'grok-beta';
