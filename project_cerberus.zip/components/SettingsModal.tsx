import React, { useState } from 'react';
import { X, CheckCircle, AlertCircle, Save } from 'lucide-react';
import { AppSettings, CharacterProfile } from '../types';
import { testGeminiConnection } from '../services/geminiService';
import { testGrokConnection } from '../services/grokService';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: AppSettings;
  character: CharacterProfile;
  onSave: (settings: AppSettings, character: CharacterProfile) => void;
}

const SettingsModal: React.FC<SettingsModalProps> = ({ isOpen, onClose, settings: initialSettings, character: initialCharacter, onSave }) => {
  const [settings, setSettings] = useState<AppSettings>(initialSettings);
  const [character, setCharacter] = useState<CharacterProfile>(initialCharacter);
  const [activeTab, setActiveTab] = useState<'api' | 'character' | 'appearance'>('api');
  const [testStatus, setTestStatus] = useState<'idle' | 'testing' | 'success' | 'failure'>('idle');

  if (!isOpen) return null;

  const handleTestConnection = async () => {
    setTestStatus('testing');
    let success = false;
    if (settings.activeProvider === 'gemini') {
      success = await testGeminiConnection(settings.apiKeyGemini);
    } else {
      success = await testGrokConnection(settings.apiKeyGrok);
    }
    setTestStatus(success ? 'success' : 'failure');
    setTimeout(() => setTestStatus('idle'), 3000);
  };

  const handleSave = () => {
    onSave(settings, character);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <div className="bg-cerberus-900 border border-cerberus-700 w-full max-w-2xl rounded-lg shadow-2xl flex flex-col max-h-[90vh]">
        
        {/* Header */}
        <div className="flex justify-between items-center p-4 border-b border-cerberus-800">
          <h2 className="text-xl font-serif text-cerberus-accent">Configuration</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-white">
            <X size={24} />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-cerberus-800">
          {(['api', 'character', 'appearance'] as const).map(tab => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`flex-1 py-3 text-sm font-medium uppercase tracking-wider transition-colors ${activeTab === tab ? 'bg-cerberus-800 text-cerberus-accent' : 'text-gray-500 hover:bg-cerberus-800/50'}`}
            >
              {tab}
            </button>
          ))}
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6 custom-scrollbar">
          
          {/* API Settings */}
          {activeTab === 'api' && (
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-bold text-gray-400 mb-2">Active Provider</label>
                <div className="flex gap-4">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input 
                      type="radio" 
                      checked={settings.activeProvider === 'gemini'}
                      onChange={() => setSettings({...settings, activeProvider: 'gemini'})}
                      className="text-cerberus-600 focus:ring-cerberus-500"
                    />
                    <span className="text-gray-200">Google Gemini</span>
                  </label>
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input 
                      type="radio" 
                      checked={settings.activeProvider === 'grok'}
                      onChange={() => setSettings({...settings, activeProvider: 'grok'})}
                      className="text-cerberus-600 focus:ring-cerberus-500"
                    />
                    <span className="text-gray-200">xAI Grok</span>
                  </label>
                </div>
              </div>

              {settings.activeProvider === 'gemini' && (
                <div className="space-y-4 border-l-2 border-cerberus-600 pl-4 animate-fadeIn">
                   <div>
                     <label className="block text-xs font-mono text-cerberus-accent mb-1">GEMINI API KEY</label>
                     <input 
                        type="password"
                        value={settings.apiKeyGemini}
                        onChange={(e) => setSettings({...settings, apiKeyGemini: e.target.value})}
                        className="w-full bg-black/50 border border-cerberus-700 rounded p-2 text-white focus:border-cerberus-500 focus:outline-none font-mono text-sm"
                        placeholder="AIzaSy..."
                     />
                   </div>
                   <div>
                     <label className="block text-xs font-mono text-cerberus-accent mb-1">MODEL</label>
                     <select 
                        value={settings.modelGemini}
                        onChange={(e) => setSettings({...settings, modelGemini: e.target.value})}
                        className="w-full bg-black/50 border border-cerberus-700 rounded p-2 text-white focus:border-cerberus-500 focus:outline-none"
                     >
                        <option value="gemini-3-pro-preview">Gemini 3 Pro Preview</option>
                        <option value="gemini-3-flash-preview">Gemini 3 Flash Preview</option>
                        <option value="gemini-2.5-flash-latest">Gemini 2.5 Flash Latest</option>
                        <option value="gemini-2.5-pro-latest">Gemini 2.5 Pro Latest</option>
                     </select>
                   </div>
                </div>
              )}

              {settings.activeProvider === 'grok' && (
                <div className="space-y-4 border-l-2 border-cerberus-600 pl-4 animate-fadeIn">
                   <div>
                     <label className="block text-xs font-mono text-cerberus-accent mb-1">GROK API KEY</label>
                     <input 
                        type="password"
                        value={settings.apiKeyGrok}
                        onChange={(e) => setSettings({...settings, apiKeyGrok: e.target.value})}
                        className="w-full bg-black/50 border border-cerberus-700 rounded p-2 text-white focus:border-cerberus-500 focus:outline-none font-mono text-sm"
                        placeholder="xai-..."
                     />
                   </div>
                   <div>
                     <label className="block text-xs font-mono text-cerberus-accent mb-1">MODEL</label>
                     <select 
                        value={settings.modelGrok}
                        onChange={(e) => setSettings({...settings, modelGrok: e.target.value})}
                        className="w-full bg-black/50 border border-cerberus-700 rounded p-2 text-white focus:border-cerberus-500 focus:outline-none"
                     >
                        <option value="grok-beta">grok-beta</option>
                        <option value="grok-vision-beta">grok-vision-beta</option>
                     </select>
                   </div>
                </div>
              )}

              <div className="pt-4 flex items-center gap-4">
                <button 
                  onClick={handleTestConnection}
                  disabled={testStatus === 'testing'}
                  className={`px-4 py-2 rounded text-sm font-bold uppercase tracking-wider flex items-center gap-2 transition-colors ${
                      testStatus === 'testing' ? 'bg-gray-700 text-gray-400' :
                      testStatus === 'success' ? 'bg-green-900 text-green-200' :
                      testStatus === 'failure' ? 'bg-red-900 text-red-200' :
                      'bg-cerberus-700 text-white hover:bg-cerberus-600'
                  }`}
                >
                  {testStatus === 'testing' && 'Connecting...'}
                  {testStatus === 'idle' && 'Test Connection'}
                  {testStatus === 'success' && <><CheckCircle size={16}/> Connected</>}
                  {testStatus === 'failure' && <><AlertCircle size={16}/> Failed</>}
                </button>
              </div>
            </div>
          )}

          {/* Character Settings */}
          {activeTab === 'character' && (
            <div className="space-y-6">
                <div>
                    <label className="block text-xs font-mono text-cerberus-accent mb-1">CHARACTER NAME</label>
                    <input 
                        type="text"
                        value={character.name}
                        onChange={(e) => setCharacter({...character, name: e.target.value})}
                        className="w-full bg-black/50 border border-cerberus-700 rounded p-2 text-white focus:border-cerberus-500"
                    />
                </div>
                <div>
                    <label className="block text-xs font-mono text-cerberus-accent mb-1">USER NAME (How she addresses you)</label>
                    <input 
                        type="text"
                        value={settings.userName}
                        onChange={(e) => setSettings({...settings, userName: e.target.value})}
                        className="w-full bg-black/50 border border-cerberus-700 rounded p-2 text-white focus:border-cerberus-500"
                    />
                </div>
                <div>
                    <label className="block text-xs font-mono text-cerberus-accent mb-1">SYSTEM PROMPT / CHARACTER SHEET</label>
                    <textarea 
                        value={character.systemPrompt}
                        onChange={(e) => setCharacter({...character, systemPrompt: e.target.value})}
                        className="w-full h-64 bg-black/50 border border-cerberus-700 rounded p-2 text-gray-300 text-xs font-mono leading-relaxed focus:border-cerberus-500 custom-scrollbar"
                    />
                </div>
            </div>
          )}

          {/* Appearance Settings */}
          {activeTab === 'appearance' && (
            <div className="space-y-6">
                 <div>
                    <label className="block text-xs font-mono text-cerberus-accent mb-1">PORTRAIT URL</label>
                    <input 
                        type="text"
                        value={character.portraitUrl}
                        onChange={(e) => setCharacter({...character, portraitUrl: e.target.value})}
                        className="w-full bg-black/50 border border-cerberus-700 rounded p-2 text-white focus:border-cerberus-500 text-xs"
                    />
                </div>
                <div>
                    <label className="block text-xs font-mono text-cerberus-accent mb-2">PORTRAIT SCALE ({settings.portraitScale}x)</label>
                    <input 
                        type="range"
                        min="0.5"
                        max="2.0"
                        step="0.1"
                        value={settings.portraitScale}
                        onChange={(e) => setSettings({...settings, portraitScale: parseFloat(e.target.value)})}
                        className="w-full accent-cerberus-600"
                    />
                </div>
                <div>
                    <label className="block text-xs font-mono text-cerberus-accent mb-2">TEMPERATURE ({settings.temperature})</label>
                    <input 
                        type="range"
                        min="0"
                        max="2"
                        step="0.1"
                        value={settings.temperature}
                        onChange={(e) => setSettings({...settings, temperature: parseFloat(e.target.value)})}
                        className="w-full accent-cerberus-600"
                    />
                    <p className="text-[10px] text-gray-500 mt-1">Higher values = more creative/chaotic. Lower = more deterministic.</p>
                </div>
            </div>
          )}

        </div>

        {/* Footer */}
        <div className="p-4 border-t border-cerberus-800 bg-cerberus-900/50 flex justify-end">
          <button 
            onClick={handleSave}
            className="flex items-center gap-2 bg-cerberus-600 hover:bg-cerberus-500 text-white px-6 py-2 rounded shadow-lg shadow-cerberus-900/50 transition-all font-serif"
          >
            <Save size={18} />
            <span>Save Configuration</span>
          </button>
        </div>

      </div>
    </div>
  );
};

export default SettingsModal;
