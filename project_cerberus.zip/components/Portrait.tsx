import React from 'react';

interface PortraitProps {
  url: string;
  scale: number;
}

const Portrait: React.FC<PortraitProps> = ({ url, scale }) => {
  // Base width 160px (w-40)
  const baseSize = 160;
  const scaledWidth = baseSize * scale;

  return (
    <div 
      className="relative rounded-sm overflow-hidden border-2 border-cerberus-800 shadow-[0_0_15px_rgba(212,175,55,0.1)] group"
      style={{ width: `${scaledWidth}px`, aspectRatio: '4/5' }}
    >
      <div className="absolute inset-0 bg-gradient-to-t from-cerberus-void/80 to-transparent z-10" />
      <img 
        src={url} 
        alt="Ysaraith" 
        className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
      />
      <div className="absolute bottom-2 left-0 right-0 text-center z-20">
         <span className="text-[10px] text-cerberus-accent font-serif tracking-[0.2em] opacity-80 shadow-black drop-shadow-md">YSARAITH</span>
      </div>
    </div>
  );
};

export default Portrait;
