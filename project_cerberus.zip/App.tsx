import React, { useState, useEffect } from 'react';
import { ChatState, Message, Thread, DEFAULT_GEMINI_MODEL, DEFAULT_GROK_MODEL } from './types';
import { DEFAULT_SETTINGS, DEFAULT_PROFILE, DEFAULT_ROOMS } from './constants';
import Sidebar from './components/Sidebar';
import ChatArea from './components/ChatArea';
import SettingsModal from './components/SettingsModal';
import { streamGeminiResponse } from './services/geminiService';
import { streamGrokResponse } from './services/grokService';
import { v4 as uuidv4 } from 'uuid';

const STORAGE_KEY = 'project_cerberus_state_v1';

const App: React.FC = () => {
  // --- State Initialization ---
  const [state, setState] = useState<ChatState>(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        // Migration/Safety check for new fields
        return {
           ...parsed,
           rooms: parsed.rooms || DEFAULT_ROOMS,
           settings: { ...DEFAULT_SETTINGS, ...parsed.settings },
           character: { ...DEFAULT_PROFILE, ...parsed.character }
        };
      } catch (e) {
        console.error("Failed to parse saved state", e);
      }
    }
    // Default State
    const initialThread: Thread = {
      id: uuidv4(),
      title: 'First Ritual',
      messages: [],
      lastUpdated: Date.now()
    };
    return {
      threads: [initialThread],
      activeThreadId: initialThread.id,
      rooms: DEFAULT_ROOMS,
      activeRoomId: DEFAULT_ROOMS[0].id,
      settings: DEFAULT_SETTINGS,
      character: DEFAULT_PROFILE
    };
  });

  const [isSidebarOpen, setSidebarOpen] = useState(false);
  const [isSettingsOpen, setSettingsOpen] = useState(false);
  const [isStreaming, setIsStreaming] = useState(false);

  // --- Persistence ---
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  }, [state]);

  // --- Helpers ---
  const getActiveThread = () => state.threads.find(t => t.id === state.activeThreadId) || state.threads[0];
  const getActiveRoom = () => state.rooms.find(r => r.id === state.activeRoomId) || state.rooms[0];

  const updateActiveThreadMessages = (newMessages: Message[]) => {
    setState(prev => ({
      ...prev,
      threads: prev.threads.map(t => 
        t.id === prev.activeThreadId 
        ? { ...t, messages: newMessages, lastUpdated: Date.now() }
        : t
      )
    }));
  };

  const updateThreadTitle = (threadId: string, title: string) => {
    setState(prev => ({
        ...prev,
        threads: prev.threads.map(t => t.id === threadId ? { ...t, title } : t)
    }));
  };

  // --- Actions ---
  const handleCreateThread = () => {
    const newThread: Thread = {
      id: uuidv4(),
      title: 'New Ritual',
      messages: [],
      lastUpdated: Date.now()
    };
    setState(prev => ({
      ...prev,
      threads: [newThread, ...prev.threads],
      activeThreadId: newThread.id
    }));
  };

  const handleDeleteThread = (id: string) => {
    if (state.threads.length <= 1) return; // Prevent deleting last thread
    const newThreads = state.threads.filter(t => t.id !== id);
    setState(prev => ({
      ...prev,
      threads: newThreads,
      activeThreadId: prev.activeThreadId === id ? newThreads[0].id : prev.activeThreadId
    }));
  };

  const handleExport = () => {
     const dataStr = JSON.stringify(state.threads, null, 2);
     const blob = new Blob([dataStr], { type: "application/json" });
     const url = URL.createObjectURL(blob);
     const link = document.createElement('a');
     link.href = url;
     link.download = `project_cerberus_export_${Date.now()}.json`;
     link.click();
  };

  const handleSendMessage = async (content: string) => {
    const activeThread = getActiveThread();
    const userMsg: Message = {
      id: uuidv4(),
      role: 'user',
      content,
      timestamp: Date.now()
    };

    // Optimistic Update
    const updatedMessages = [...activeThread.messages, userMsg];
    updateActiveThreadMessages(updatedMessages);
    
    // Auto-Title Logic
    if (activeThread.messages.length === 0) {
        const words = content.split(' ').slice(0, 5).join(' ');
        updateThreadTitle(activeThread.id, words + '...');
    }

    setIsStreaming(true);

    // Placeholder for model response
    const modelMsgId = uuidv4();
    const modelMsg: Message = {
      id: modelMsgId,
      role: 'model',
      content: '', // Start empty
      timestamp: Date.now()
    };
    
    // Add empty model message to state so we can stream into it
    updateActiveThreadMessages([...updatedMessages, modelMsg]);

    let fullResponseText = '';

    try {
      const room = getActiveRoom();
      const onChunk = (text: string) => {
        fullResponseText += text; // Use local var to avoid closure staleness issues with simple state updates if complex
        // Update state with new full text
        setState(prev => ({
            ...prev,
            threads: prev.threads.map(t => {
                if (t.id !== prev.activeThreadId) return t;
                const msgs = [...t.messages];
                // Find the placeholder we just added. It should be the last one.
                const last = msgs[msgs.length - 1];
                if (last.id === modelMsgId) {
                    last.content = fullResponseText;
                }
                return { ...t, messages: msgs };
            })
        }));
      };

      if (state.settings.activeProvider === 'gemini') {
        await streamGeminiResponse(
          updatedMessages, 
          room, 
          state.settings, 
          state.character, 
          onChunk
        );
      } else {
        await streamGrokResponse(
          updatedMessages, 
          room, 
          state.settings, 
          state.character, 
          onChunk
        );
      }

    } catch (error) {
      console.error("Streaming error", error);
      // Append error message
      setState(prev => ({
            ...prev,
            threads: prev.threads.map(t => {
                if (t.id !== prev.activeThreadId) return t;
                const msgs = [...t.messages];
                const last = msgs[msgs.length - 1];
                if (last.id === modelMsgId) {
                    last.content = fullResponseText + "\n\n*[Connection severed by the Void. Check your API configuration.]*";
                }
                return { ...t, messages: msgs };
            })
        }));
    } finally {
      setIsStreaming(false);
    }
  };

  return (
    <div className="flex h-screen bg-cerberus-void text-gray-200 overflow-hidden font-sans">
      <Sidebar
        threads={state.threads}
        activeThreadId={state.activeThreadId}
        onSelectThread={(id) => setState(prev => ({ ...prev, activeThreadId: id }))}
        onCreateThread={handleCreateThread}
        onDeleteThread={handleDeleteThread}
        onOpenSettings={() => setSettingsOpen(true)}
        isOpen={isSidebarOpen}
        onClose={() => setSidebarOpen(false)}
        onExport={handleExport}
      />

      <ChatArea
        messages={getActiveThread().messages}
        isStreaming={isStreaming}
        onSendMessage={handleSendMessage}
        onSidebarToggle={() => setSidebarOpen(!isSidebarOpen)}
        character={state.character}
        portraitScale={state.settings.portraitScale}
        activeRoom={getActiveRoom()}
        rooms={state.rooms}
        onRoomChange={(roomId) => setState(prev => ({ ...prev, activeRoomId: roomId }))}
      />

      <SettingsModal
        isOpen={isSettingsOpen}
        onClose={() => setSettingsOpen(false)}
        settings={state.settings}
        character={state.character}
        onSave={(newSettings, newChar) => setState(prev => ({ ...prev, settings: newSettings, character: newChar }))}
      />
    </div>
  );
};

export default App;
